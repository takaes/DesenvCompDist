package com.example.oauth;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;

@RestController
public class Controller {

	@GetMapping("/")
	public String ola() {
		return "Olá";
	}
	
	@GetMapping("/restricted")
	public String restricted() {
		return "Você está logado!";
	}

}
